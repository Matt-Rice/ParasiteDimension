﻿using Microsoft.EntityFrameworkCore;
using Thing.Models;

namespace Thing;
    public class AppDbContext : DbContext
    {
        public DbSet<Battle> Battles { get; set; }
        public DbSet<Enemy> Enemies { get; set; }
        public DbSet<Skill> Skills { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder options) => options.UseSqlite("Data Source=app.db");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Enemy>()
            .HasOne(e => e.Battle)
            .WithMany(b => b.EnemyList)
            .HasForeignKey(e => e.BattleId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<Skill>()
            .HasOne(s => s.Enemy)
            .WithMany(e => e.SkillList)
            .HasForeignKey(s => s.SkillId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}

