﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Thing.Models
{
    public class Enemy
    {
        public int EnemyId { get; set; }
        public string Name { get; set; } = string.Empty;
        public List<Skill> SkillList { get; set; } = new();
        public int BattleId { get; set; }
        public Battle Battle { get; set; }
    }
}
