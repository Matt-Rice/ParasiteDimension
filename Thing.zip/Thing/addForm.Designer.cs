﻿namespace Thing
{
    partial class addForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            saveButton = new Button();
            descriptionBox = new TextBox();
            nameBox = new TextBox();
            descriptionLabel = new Label();
            nameLabel = new Label();
            cancelButton = new Button();
            enemyLabel = new Label();
            SuspendLayout();
            // 
            // saveButton
            // 
            saveButton.Location = new Point(720, 407);
            saveButton.Name = "saveButton";
            saveButton.Size = new Size(68, 31);
            saveButton.TabIndex = 0;
            saveButton.Text = "Save";
            saveButton.UseVisualStyleBackColor = true;
            saveButton.Click += Save_Click;
            // 
            // descriptionBox
            // 
            descriptionBox.Location = new Point(21, 97);
            descriptionBox.Multiline = true;
            descriptionBox.Name = "descriptionBox";
            descriptionBox.PlaceholderText = "Description";
            descriptionBox.Size = new Size(185, 341);
            descriptionBox.TabIndex = 11;
            // 
            // nameBox
            // 
            nameBox.Location = new Point(41, 44);
            nameBox.Name = "nameBox";
            nameBox.PlaceholderText = "Name";
            nameBox.Size = new Size(165, 23);
            nameBox.TabIndex = 10;
            // 
            // descriptionLabel
            // 
            descriptionLabel.AutoSize = true;
            descriptionLabel.Location = new Point(73, 79);
            descriptionLabel.Name = "descriptionLabel";
            descriptionLabel.Size = new Size(67, 15);
            descriptionLabel.TabIndex = 9;
            descriptionLabel.Text = "Description";
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new Point(88, 26);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new Size(39, 15);
            nameLabel.TabIndex = 8;
            nameLabel.Text = "Name";
            // 
            // cancelButton
            // 
            cancelButton.Location = new Point(632, 407);
            cancelButton.Name = "cancelButton";
            cancelButton.Size = new Size(68, 31);
            cancelButton.TabIndex = 12;
            cancelButton.Text = "Cancel";
            cancelButton.UseVisualStyleBackColor = true;
            // 
            // enemyLabel
            // 
            enemyLabel.AutoSize = true;
            enemyLabel.Location = new Point(275, 26);
            enemyLabel.Name = "enemyLabel";
            enemyLabel.Size = new Size(51, 15);
            enemyLabel.TabIndex = 13;
            enemyLabel.Text = "Enemies";
            // 
            // addForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(enemyLabel);
            Controls.Add(cancelButton);
            Controls.Add(descriptionBox);
            Controls.Add(nameBox);
            Controls.Add(descriptionLabel);
            Controls.Add(nameLabel);
            Controls.Add(saveButton);
            Name = "addForm";
            Text = "addForm";
            Load += addForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button saveButton;
        private TextBox descriptionBox;
        private TextBox nameBox;
        private Label descriptionLabel;
        private Label nameLabel;
        private Button cancelButton;
        private Label enemyLabel;
    }
}