namespace Thing
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void editButton_Click(object sender, EventArgs e)
        {
            OpenModal();
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            OpenModal();
        }

        private void newButton_Click(object sender, EventArgs e)
        {

            OpenModal();
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            LoadBattles();
        }

        public void OpenModal()
        {
            using (var modal = new addForm())
            {
                var result = modal.ShowDialog();

                if (result == DialogResult.OK)
                {
                    MessageBox.Show("Okay");
                }
                else if (result == DialogResult.Cancel)
                {
                    MessageBox.Show("Cancelled");
                }
            }
        }

        public void LoadBattles()
        {
            using var db = new AppDbContext();

            var battles = db.Battles
                .OrderBy(b => b.Name)
                .ToList();

            battleListBox.DataSource = battles;
            battleListBox.DisplayMember = "Name";
            battleListBox.ValueMember = "BattleId";
        }

    }
}
