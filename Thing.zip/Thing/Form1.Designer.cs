﻿namespace Thing
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            battleListBox = new ListBox();
            newButton = new Button();
            editButton = new Button();
            deleteButton = new Button();
            SuspendLayout();
            // 
            // battleListBox
            // 
            battleListBox.FormattingEnabled = true;
            battleListBox.ItemHeight = 15;
            battleListBox.Location = new Point(12, 25);
            battleListBox.Name = "battleListBox";
            battleListBox.Size = new Size(163, 229);
            battleListBox.TabIndex = 0;
            // 
            // newButton
            // 
            newButton.Location = new Point(125, 260);
            newButton.Name = "newButton";
            newButton.Size = new Size(50, 23);
            newButton.TabIndex = 1;
            newButton.Text = "New";
            newButton.UseVisualStyleBackColor = true;
            newButton.Click += newButton_Click;
            // 
            // editButton
            // 
            editButton.Location = new Point(71, 260);
            editButton.Name = "editButton";
            editButton.Size = new Size(48, 23);
            editButton.TabIndex = 2;
            editButton.Text = "Edit";
            editButton.UseVisualStyleBackColor = true;
            editButton.Click += editButton_Click;
            // 
            // deleteButton
            // 
            deleteButton.Location = new Point(15, 260);
            deleteButton.Name = "deleteButton";
            deleteButton.Size = new Size(50, 23);
            deleteButton.TabIndex = 3;
            deleteButton.Text = "Delete";
            deleteButton.UseVisualStyleBackColor = true;
            deleteButton.Click += deleteButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(deleteButton);
            Controls.Add(editButton);
            Controls.Add(newButton);
            Controls.Add(battleListBox);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
        }

        #endregion

        private ListBox battleListBox;
        private Button newButton;
        private Button editButton;
        private Button deleteButton;
    }
}
